# InstagramKit
PHP Curl Instagram

## Installation
```bash
composer require riedayme/instagramkit dev-master
```

## Usage The Script
```
View on examples folder
```

## Featured Scripts Ready to Run
* Auto Like Time Line [WITH COMMENTS]
* Auto View Story
* Mass View and Vote Story [NEW]
```
the Script locate on folder scripts

Run Auto View Story :
php AVS.php

Run Auto Like TimeLine :
php ALT.php

Run Auto Mass View And Vote Story [Story Vote Kuy]
php SVK.php
```

## Change Log
**20 Juni 2020**
- Add Scripts Story Vote Kuy
- Fix Bug

**6 Juni 2020**
- Release

**10 Juni 2020**
- Fix Bug
- Add Story script